<?php 

// definition des constantes pour la base de donné

define("BD_USER", "root");

define("BD_MDP", "root");

define("BD_NAME", "portail_kbm");

?>