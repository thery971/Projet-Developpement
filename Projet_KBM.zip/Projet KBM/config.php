<?php  

	$login_client="C_pseudo";
	$mdp_client="lol";
	$login_admin="A_pseudo";
	$mdp_admin="lol";
	$login_membre="M_pseudo";
	$mdp_membre="lol";
	$login_r="R_pseudo";
	$mdp_r="lol";
	$login_producteur="P_pseudo";
	$mdp_producteur="lol";



?>